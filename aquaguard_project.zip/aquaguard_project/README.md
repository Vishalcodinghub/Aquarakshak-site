# AquaGuard — Smart Water Purification & Quality Monitoring System

This package is a fully runnable software prototype based on the supplied AquaGuard interface.

## Run on Windows

1. Install Python 3.10+.
2. Double-click `run.bat` OR open a terminal in this folder and run:

```bash
python app.py
```

3. The dashboard opens at `http://127.0.0.1:8501/index.html`.

## Run without Python

Open `index.html` directly in a browser. Most UI features run locally using browser JavaScript/localStorage.

## Included modules

- `index.html` — complete UI structure
- `css/style.css` — responsive dashboard styling
- `js/storage.js` — local data persistence
- `js/quality.js` — water-quality rules and score
- `js/sensors.js` — sensor simulation/scenarios
- `js/purification.js` — multi-stage purification animation
- `js/alerts.js` — alert handling
- `js/charts.js` — dashboard charts
- `js/ui.js` — navigation/sidebar behavior
- `js/app.js` — application orchestration
- `js/vendor/chart.umd.min.js` — offline lightweight chart renderer
- `app.py` — local Python web server

All sensor/location values are simulated for demonstration and are not laboratory results.
