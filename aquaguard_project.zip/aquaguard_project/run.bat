@echo off
setlocal
cd /d "%~dp0"
python app.py
if errorlevel 1 (
  echo.
  echo Python was not found. Install Python 3.10+ and try again.
  pause
)
