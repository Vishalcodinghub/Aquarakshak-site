from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import webbrowser

ROOT = Path(__file__).parent
PORT = 8501

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)
    def log_message(self, fmt, *args):
        print('[AquaGuard]', fmt % args)

if __name__ == '__main__':
    url = f'http://127.0.0.1:{PORT}/index.html'
    print('AquaGuard running at', url)
    server = ThreadingHTTPServer(('127.0.0.1', PORT), Handler)
    try:
        webbrowser.open(url)
        server.serve_forever()
    except KeyboardInterrupt:
        print('\nStopped.')
    finally:
        server.server_close()
