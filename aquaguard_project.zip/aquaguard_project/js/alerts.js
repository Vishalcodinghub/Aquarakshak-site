(function(){
  window.AQAlerts={add(state,reading,status){if(status==='SAFE')return;const reason=window.AQQuality.reason(reading,state.settings);const exists=state.alerts.find(a=>a.active&&a.reason===reason);if(!exists)state.alerts.unshift({id:Date.now()+Math.random(),ts:Date.now(),status,reason,active:true,scenario:state.scenario});state.alerts=state.alerts.slice(0,100)},resolveAll(state){state.alerts.forEach(a=>{a.active=false;a.resolvedTs=Date.now()})}}
})();
