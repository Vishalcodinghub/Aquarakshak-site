(function(){
  const KEY='aquaguard_state_v1';
  const defaults={settings:{phMin:6.5,phMax:8.5,turbidityWarn:4,turbidityUnsafe:10,tdsWarn:500,tdsUnsafe:1200,tempMin:10,tempMax:35,alertSensitivity:'normal',monitoringInterval:3,simulationMode:'standard'},history:[],alerts:[],scenario:'Default'};
  function clone(x){return JSON.parse(JSON.stringify(x))}
  window.AQStore={load(){try{const s=JSON.parse(localStorage.getItem(KEY)||'null');return Object.assign(clone(defaults),s||{},s?.settings?{settings:Object.assign(clone(defaults.settings),s.settings)}:{});}catch(e){return clone(defaults)}},save(s){localStorage.setItem(KEY,JSON.stringify(s))},defaults:clone(defaults),clear(){localStorage.removeItem(KEY)}};
})();
