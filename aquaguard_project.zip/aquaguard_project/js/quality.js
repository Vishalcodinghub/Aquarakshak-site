window.AQQuality={
  paramStatus(type,v,s){
    if(type==='ph') return v<s.phMin||v>s.phMax?'UNSAFE':(v<s.phMin+.3||v>s.phMax-.3?'WARNING':'SAFE');
    if(type==='turb') return v>s.turbidityUnsafe?'UNSAFE':(v>s.turbidityWarn?'WARNING':'SAFE');
    if(type==='tds') return v>s.tdsUnsafe?'UNSAFE':(v>s.tdsWarn?'WARNING':'SAFE');
    if(type==='temp') return v<s.tempMin-3||v>s.tempMax+3?'UNSAFE':(v<s.tempMin||v>s.tempMax?'WARNING':'SAFE');
    return 'SAFE';
  },overall(r,s){const a=[this.paramStatus('ph',r.ph,s),this.paramStatus('turb',r.turbidity,s),this.paramStatus('tds',r.tds,s),this.paramStatus('temp',r.temp,s)];if(a.includes('UNSAFE'))return'UNSAFE';if(a.includes('WARNING'))return'WARNING';return'SAFE'},score(r,s){let q=[];q.push(Math.max(0,100-Math.abs(r.ph-7.3)*22));q.push(Math.max(0,100-Math.max(0,r.turbidity)*7));q.push(Math.max(0,100-Math.max(0,r.tds-150)*.08));q.push(Math.max(0,100-Math.abs(r.temp-24)*2.4));return Math.max(0,Math.min(100,Math.round(q.reduce((a,b)=>a+b,0)/4)))},
  label(st){return st},reason(r,s){const msgs=[];[['pH',r.ph,this.paramStatus('ph',r.ph,s)],['Turbidity',r.turbidity,this.paramStatus('turb',r.turbidity,s)],['TDS',r.tds,this.paramStatus('tds',r.tds,s)],['Temperature',r.temp,this.paramStatus('temp',r.temp,s)]].forEach(x=>{if(x[2]!=='SAFE')msgs.push(x[0]+' is '+x[1])});return msgs.length?msgs.join(' · '):'All monitored parameters are within configured thresholds.'}
};
