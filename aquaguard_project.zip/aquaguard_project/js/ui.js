(function(){
  const nav=document.querySelectorAll('.nav-item[data-page]'); const pages=document.querySelectorAll('.page'); const title=document.getElementById('pageTitle');
  function go(page){nav.forEach(n=>n.classList.toggle('active',n.dataset.page===page));pages.forEach(p=>p.classList.toggle('active',p.id==='page-'+page));const n=[...nav].find(x=>x.dataset.page===page);if(n)title.textContent=n.textContent.replace(/^[^A-Za-z]+/,'').replace(/\d+$/,'');history.replaceState(null,'','#'+page);window.scrollTo({top:0,behavior:'smooth'});}
  nav.forEach(n=>n.addEventListener('click',()=>go(n.dataset.page)));document.querySelectorAll('[data-page]').forEach(n=>n.addEventListener('click',e=>{if(n.classList.contains('nav-item'))return;go(n.dataset.page)}));
  document.getElementById('hamburger')?.addEventListener('click',()=>{document.getElementById('sidebar').classList.toggle('open');document.getElementById('sidebarBackdrop').classList.toggle('show')});document.getElementById('sidebarBackdrop')?.addEventListener('click',()=>{document.getElementById('sidebar').classList.remove('open');document.getElementById('sidebarBackdrop').classList.remove('show')});
  window.AQUI={go};
})();
