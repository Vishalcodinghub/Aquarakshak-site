(function(){
  const charts={}; const colors=['#0284c7','#16a34a','#d97706','#7c3aed','#ef4444'];
  function values(hist,k){return hist.slice(-20).map(x=>x[k])}; function labels(hist){return hist.slice(-20).map(x=>new Date(x.ts).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}))};
  function draw(id,labels_,dataSets,type='line'){const el=document.getElementById(id);if(!el)return;const ctx=el.getContext('2d');if(charts[id])charts[id].destroy();charts[id]=new Chart(ctx,{type,data:{labels:labels_,datasets:dataSets},options:{responsive:true,maintainAspectRatio:false}})}
  window.AQCharts={render(state){const h=state.history;const l=labels(h);draw('overviewChart',l,[{data:values(h,'score'),borderColor:colors[0]}]);draw('liveChart',l,[{data:values(h,'ph'),borderColor:colors[0]},{data:values(h,'turbidity'),borderColor:colors[2]},{data:values(h,'tds').map(v=>v/20),borderColor:colors[3]}]);
    [['ph','hist-ph'],['turbidity','hist-turb'],['tds','hist-tds'],['temp','hist-temp'],['score','hist-score']].forEach((p,i)=>draw(p[1],l,[{data:values(h,p[0]),borderColor:colors[i%colors.length]}]));
    draw('beforeAfterChart',['Before','After'],[{data:[state.before?.score||60,state.after?.score||85],backgroundColor:colors[0],borderColor:colors[0]}],'bar');draw('treatedChart',l,[{data:values(h,'afterScore'),borderColor:colors[1]}]);
    ['ph','turbidity','tds','temp'].forEach(k=>{const c=document.getElementById('spark-'+(k==='turbidity'?'turbidity':k));if(!c)return;const mini=new Chart(c.getContext('2d'),{type:'line',data:{labels:l,datasets:[{data:values(h,k),borderColor:colors[0]}]}});});
  }};
})();
